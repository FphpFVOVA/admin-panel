<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="css/style.css">
	<link rel="shortcut icon" href="img/password.png" type="image/png">
	<title>Admin-login</title>
</head>
<body style="background-color: #A7A7A7">
	<form class="" action="includes/.login.php" method="post">
		<div class="">
			<p class="password-text">Пароль</p>
			<center><input type="password" name="programs_language" class="admin-login"></center>
			<br>
			<button type="submit" class="button-auth" title="Админ-панель находитса в бета тесте!">Вход</button>
		</div>
	</form>
</body>
</html>
