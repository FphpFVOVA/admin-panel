<?php

session_start();
unset($_SESSION['programs_language']);
header("Location: /Go-to.php");
