<?php
  if (isset($_POST['programs_language']) AND trim($_POST['programs_language'])) {
    if ($_POST['programs_language'] == "admin") {
      session_start();
      $_SESSION['programs_language'] = $_POST['programs_language'];

      header("Location: ../suc.php");
    }
    else {
      header("Location: ../Go-to.php");
    }
  }
  else {
    header("Location: ../Go-to.php");
  }
?>
