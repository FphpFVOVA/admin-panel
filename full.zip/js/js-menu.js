function hide() {
	document.getElementById(123).style.visibility = "hidden";
  document.getElementById(5555).style.visibility = "hidden";
}
function hides(){
	document.getElementById(1233).style.visibility = "hidden";
  document.getElementById(123).style.visibility = "visible";
  document.getElementById(5555).style.visibility = "visible";
}
function hidesss(){
  document.getElementById(123).style.visibility = "hidden";
  document.getElementById(1233).style.visibility = "visible";
  document.getElementById(5555).style.visibility = "hidden";
}
hide();
